#! /usr/bin/env sh

R -f tests/test_all.r
